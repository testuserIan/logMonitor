﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using WinSCP;

namespace LogMonitorTest
{
    public partial class LogViewerForm : DevExpress.XtraEditors.XtraForm
    {
        string env = "PROD";
        Session winscpSession;
        public LogViewerForm()
        {
            InitializeComponent();
            SetEnvironmentWarnings();
            SetDefaultFormValues();
            Thread checkConnectionStatus = new(() => CheckConnectionStatusLoop());
        }

        bool shouldCheckStatus = true;
        private void CheckConnectionStatusLoop()
        {
            try
            {
                while (shouldCheckStatus)
                    CheckWinSCPSessionStatus();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Connection Status Loop Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CheckWinSCPSessionStatus()
        {
            if (winscpSession == null || !winscpSession.Opened)
            {
                labelWinSCPConnectionStatus.Text = "DISCONNECTED";
                labelWinSCPConnectionStatus.BackColor = Color.Red;
            }
            else if (winscpSession != null && winscpSession.Opened)
            {
                labelWinSCPConnectionStatus.Text = "CONNECTED";
                labelWinSCPConnectionStatus.BackColor = Color.Green;
            }
        }

        private void SetDefaultFormValues()
        {
            labelWinSCPConnectionStatus.Text = "DISCONNECTED";
            labelWinSCPConnectionStatus.BackColor = Color.Red;
        }

        private void SetEnvironmentWarnings()
        {
            if (env == "PROD")
            {
                panel1.BackColor = Color.Firebrick;
                labelEnvWarning.Text = "THIS IS PROD THIS IS PROD";
                labelEnvWarning.ForeColor = Color.Yellow;
            }
        }

        private void simpleButtonConnect_Click(object sender, EventArgs e)
        {
            try
            {
                Form form = new WinSCPConnectionForm(this);
                form.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Connect Form Open Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        internal void AsyncConnect(SessionOptions sessionOptions)
        {
            Thread conThread = new(() => Connect(sessionOptions));
            conThread.Start();
        }

        private void Connect(SessionOptions sessionOptions)
        {
            try
            {
                EndSessionIfExists();
                StartNewSession(sessionOptions);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "WinSCP Connect  Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void StartNewSession(SessionOptions sessionOptions)
        {
            winscpSession = new Session();
            winscpSession.Failed += WinSCP_Failed;
            winscpSession.FileTransferProgress += WinSCP_FileTransferProgress;
            winscpSession.FileTransferred += WinSCP_FileTransferred;
            winscpSession.Open(sessionOptions);
        }

        private void EndSessionIfExists()
        {
            if (winscpSession != null)
            {
                winscpSession.Failed -= WinSCP_Failed;
                winscpSession.FileTransferProgress -= WinSCP_FileTransferProgress;
                winscpSession.FileTransferred -= WinSCP_FileTransferred;
                winscpSession.Close();
                winscpSession.Dispose();
            }
        }

        private void WinSCP_FileTransferred(object sender, TransferEventArgs e)
        {
            try
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "WinSCP_FileTransferred Handler Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void WinSCP_FileTransferProgress(object sender, FileTransferProgressEventArgs e)
        {
            try
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "WinSCP_FileTransferProgress Handler Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void WinSCP_Failed(object sender, FailedEventArgs e)
        {
            try
            {
                MessageBox.Show(e.Error.Message, "WinSCP Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "WinSCP_Failed Handler Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LogViewerForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            shouldCheckStatus = false;
            EndSessionIfExists();
        }
    }
}
