﻿namespace LogMonitorTest
{
    partial class LogViewerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelWinSCPConnectionStatus = new System.Windows.Forms.Label();
            this.simpleButtonWinSCPConnect = new DevExpress.XtraEditors.SimpleButton();
            this.labelEnvWarning = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelWinSCP = new System.Windows.Forms.Label();
            this.labelRAS = new System.Windows.Forms.Label();
            this.labelRasConnectionStatus = new System.Windows.Forms.Label();
            this.simpleButtonRASConnect = new DevExpress.XtraEditors.SimpleButton();
            this.treeList1 = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treeList1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(839, 596);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.labelRAS);
            this.panel1.Controls.Add(this.labelRasConnectionStatus);
            this.panel1.Controls.Add(this.simpleButtonRASConnect);
            this.panel1.Controls.Add(this.labelWinSCP);
            this.panel1.Controls.Add(this.labelWinSCPConnectionStatus);
            this.panel1.Controls.Add(this.simpleButtonWinSCPConnect);
            this.panel1.Controls.Add(this.labelEnvWarning);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(833, 124);
            this.panel1.TabIndex = 0;
            // 
            // labelWinSCPConnectionStatus
            // 
            this.labelWinSCPConnectionStatus.AutoSize = true;
            this.labelWinSCPConnectionStatus.Location = new System.Drawing.Point(668, 15);
            this.labelWinSCPConnectionStatus.Name = "labelWinSCPConnectionStatus";
            this.labelWinSCPConnectionStatus.Size = new System.Drawing.Size(85, 13);
            this.labelWinSCPConnectionStatus.TabIndex = 2;
            this.labelWinSCPConnectionStatus.Text = "DISCONNECTED";
            // 
            // simpleButtonWinSCPConnect
            // 
            this.simpleButtonWinSCPConnect.Location = new System.Drawing.Point(507, 12);
            this.simpleButtonWinSCPConnect.Name = "simpleButtonWinSCPConnect";
            this.simpleButtonWinSCPConnect.Size = new System.Drawing.Size(105, 19);
            this.simpleButtonWinSCPConnect.TabIndex = 1;
            this.simpleButtonWinSCPConnect.Text = "Connect";
            this.simpleButtonWinSCPConnect.Click += new System.EventHandler(this.simpleButtonConnect_Click);
            // 
            // labelEnvWarning
            // 
            this.labelEnvWarning.AutoSize = true;
            this.labelEnvWarning.Location = new System.Drawing.Point(349, 15);
            this.labelEnvWarning.Name = "labelEnvWarning";
            this.labelEnvWarning.Size = new System.Drawing.Size(152, 13);
            this.labelEnvWarning.TabIndex = 0;
            this.labelEnvWarning.Text = "ENV WARNING ENV WARNING";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.treeList1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 133);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(833, 460);
            this.panel2.TabIndex = 1;
            // 
            // labelWinSCP
            // 
            this.labelWinSCP.AutoSize = true;
            this.labelWinSCP.Location = new System.Drawing.Point(618, 15);
            this.labelWinSCP.Name = "labelWinSCP";
            this.labelWinSCP.Size = new System.Drawing.Size(44, 13);
            this.labelWinSCP.TabIndex = 3;
            this.labelWinSCP.Text = "WinSCP";
            // 
            // labelRAS
            // 
            this.labelRAS.AutoSize = true;
            this.labelRAS.Location = new System.Drawing.Point(618, 40);
            this.labelRAS.Name = "labelRAS";
            this.labelRAS.Size = new System.Drawing.Size(27, 13);
            this.labelRAS.TabIndex = 6;
            this.labelRAS.Text = "RAS";
            // 
            // labelRasConnectionStatus
            // 
            this.labelRasConnectionStatus.AutoSize = true;
            this.labelRasConnectionStatus.Location = new System.Drawing.Point(668, 40);
            this.labelRasConnectionStatus.Name = "labelRasConnectionStatus";
            this.labelRasConnectionStatus.Size = new System.Drawing.Size(85, 13);
            this.labelRasConnectionStatus.TabIndex = 5;
            this.labelRasConnectionStatus.Text = "DISCONNECTED";
            // 
            // simpleButtonRASConnect
            // 
            this.simpleButtonRASConnect.Location = new System.Drawing.Point(507, 37);
            this.simpleButtonRASConnect.Name = "simpleButtonRASConnect";
            this.simpleButtonRASConnect.Size = new System.Drawing.Size(105, 19);
            this.simpleButtonRASConnect.TabIndex = 4;
            this.simpleButtonRASConnect.Text = "Connect";
            // 
            // treeList1
            // 
            this.treeList1.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn1});
            this.treeList1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeList1.Location = new System.Drawing.Point(0, 0);
            this.treeList1.Name = "treeList1";
            this.treeList1.BeginUnboundLoad();
            this.treeList1.AppendNode(new object[] {
            null}, -1);
            this.treeList1.AppendNode(new object[] {
            null}, 0);
            this.treeList1.AppendNode(new object[] {
            null}, 0);
            this.treeList1.AppendNode(new object[] {
            null}, 2);
            this.treeList1.AppendNode(new object[] {
            null}, 2);
            this.treeList1.AppendNode(new object[] {
            null}, 2);
            this.treeList1.AppendNode(new object[] {
            null}, 5);
            this.treeList1.AppendNode(new object[] {
            null}, 5);
            this.treeList1.AppendNode(new object[] {
            null}, 5);
            this.treeList1.AppendNode(new object[] {
            null}, 2);
            this.treeList1.AppendNode(new object[] {
            null}, 0);
            this.treeList1.AppendNode(new object[] {
            null}, 0);
            this.treeList1.AppendNode(new object[] {
            null}, 0);
            this.treeList1.EndUnboundLoad();
            this.treeList1.Size = new System.Drawing.Size(833, 460);
            this.treeList1.TabIndex = 0;
            // 
            // treeListColumn1
            // 
            this.treeListColumn1.Caption = "treeListColumn1";
            this.treeListColumn1.FieldName = "treeListColumn1";
            this.treeListColumn1.Name = "treeListColumn1";
            this.treeListColumn1.Visible = true;
            this.treeListColumn1.VisibleIndex = 0;
            // 
            // LogViewerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(839, 596);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "LogViewerForm";
            this.Text = "Log Viewer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.LogViewerForm_FormClosing);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.treeList1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelEnvWarning;
        private DevExpress.XtraEditors.SimpleButton simpleButtonWinSCPConnect;
        private System.Windows.Forms.Label labelWinSCPConnectionStatus;
        private System.Windows.Forms.Label labelWinSCP;
        private System.Windows.Forms.Label labelRAS;
        private System.Windows.Forms.Label labelRasConnectionStatus;
        private DevExpress.XtraEditors.SimpleButton simpleButtonRASConnect;
        private DevExpress.XtraTreeList.TreeList treeList1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn1;
    }
}

