﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinSCP;

namespace LogMonitorTest
{
    public partial class WinSCPConnectionForm : DevExpress.XtraEditors.XtraForm
    {
        private readonly LogViewerForm logViewerForm;

        public WinSCPConnectionForm(LogViewerForm logViewerForm)
        {
            InitializeComponent();
            this.logViewerForm = logViewerForm;
        }

        private void simpleButtonOk_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(textBoxHost.Text))
            {
                MessageBox.Show("Host null or empty!", "Invalid Form", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (String.IsNullOrWhiteSpace(textBoxUser.Text))
            {
                MessageBox.Show("User null or empty!", "Invalid Form", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (String.IsNullOrWhiteSpace(textBoxPwd.Text))
            {
                MessageBox.Show("Pwd null or empty!", "Invalid Form", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            SessionOptions sessionOptions = new SessionOptions()
            {
                Protocol = Protocol.Sftp,
                HostName = textBoxHost.Text,
                UserName = textBoxUser.Text,
                Password = textBoxPwd.Text
            };

            logViewerForm.AsyncConnect(sessionOptions);
            this.Close();
        }
    }
}