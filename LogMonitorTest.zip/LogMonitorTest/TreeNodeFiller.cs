﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogMonitorTest
{
    internal class TreeNodeFiller
    {
        private void FillTreeDialogWithFiles()
        {
            //var files = Directory.GetFiles(, "*", SearchOption.AllDirectories);
        }
    }
}
